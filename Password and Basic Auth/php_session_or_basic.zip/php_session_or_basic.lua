-- php_session_or_basic.lua (safe load: no use of `r` at top-level)

local PHP_SESSION_COOKIE = "GeTolv"
local PHP_SESSION_PATH   = "D:/PHPSess"

local function log_info(r, msg)
  -- Only log if r exists (defensive)
  if r and r.info then r:info(msg) end
end

local function get_cookie_value(r, name)
  local h = r.headers_in["Cookie"]
  log_info(r, "Lua: method=" .. tostring(r.method) .. " uri=" .. tostring(r.unparsed_uri or r.uri))

  if not h then
    --log_info(r, "Lua: no Cookie header")
    return nil
  end

  --log_info(r, "Lua: Cookie header: " .. h)

  local esc = name:gsub("(%W)", "%%%1")
  local v = h:match(esc .. "=([^;]+)")

  if v then
    log_info(r, "Lua: found cookie " .. name .. "=" .. v)
  else
    log_info(r, "Lua: cookie " .. name .. " NOT found")
  end

  return v
end

local function read_all(path)
  local f = io.open(path, "rb")
  if not f then return nil end
  local data = f:read("*a")
  f:close()
  return data
end

local function sane_sid(sid)
  return sid and sid:match("^[A-Za-z0-9%-_,]+$") ~= nil
end

local function session_is_logged_in(r, sessfile)
  local data = read_all(sessfile)
  if not data then
    --log_info(r, "Lua: session file missing/unreadable: " .. sessfile)
    return false
  end

  -- Require both markers:
  local has_userid = data:find("userId|i:", 1, true) ~= nil
  local has_usermail = data:find("userMail|s:", 1, true) ~= nil

  --log_info(r, "Lua: marker userId present: " .. tostring(has_userid))
  log_info(r, "Lua: marker userMail present: " .. tostring(has_usermail))

  return has_userid and has_usermail
end

function check_access(r)
  -- IMPORTANT: nothing above this point should reference `r` outside a function call.
  local sid = get_cookie_value(r, PHP_SESSION_COOKIE)

  if not sid or sid == "" then
    --log_info(r, "Lua: no session id -> DECLINED (Basic will run)")
    return apache2.DECLINED
  end

  if not sane_sid(sid) then
    --log_info(r, "Lua: session id not sane -> DECLINED (Basic will run)")
    return apache2.DECLINED
  end

  local sessfile = PHP_SESSION_PATH .. "/sess_" .. sid
  --log_info(r, "Lua: checking session file: " .. sessfile)

  if session_is_logged_in(r, sessfile) then
    r.user = "php-session"
    log_info(r, "Lua: AUTH OK -> OK (bypass Basic)")
    return apache2.OK
  end

  log_info(r, "Lua: AUTH FAIL -> DECLINED (Basic will run)")
  return apache2.DECLINED
end
